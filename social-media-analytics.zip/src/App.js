import React from 'react';
import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';
import Feed from './components/Feed';
import TopUsers from './components/TopUsers';
import TrendingPosts from './components/TrendingPosts';
import './App.css';

function App() {
  return (
    <Router>
      <div className="app-container">
        <header className="header">
          <h1>📊 Social Media Analytics</h1>
        </header>

        <nav className="navbar">
          <NavLink to="/" exact="true" className="nav-link" activeclassname="active">Feed</NavLink>
          <NavLink to="/top-users" className="nav-link" activeclassname="active">Top Users</NavLink>
          <NavLink to="/trending-posts" className="nav-link" activeclassname="active">Trending Posts</NavLink>
        </nav>

        <main className="main-content">
          <Routes>
            <Route path="/" element={<Feed />} />
            <Route path="/top-users" element={<TopUsers />} />
            <Route path="/trending-posts" element={<TrendingPosts />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;
