import React, { useState, useEffect } from 'react';
import { posts as initialPosts } from '../mockData';
import { users } from '../mockData';
const Feed = () => {
  const [feed, setFeed] = useState(initialPosts);

  useEffect(() => {
    const interval = setInterval(() => {
      const randomUser = users[Math.floor(Math.random() * users.length)];

      const newPost = {
        id: Date.now(),
        userId: randomUser.id,
        content: "New post at " + new Date().toLocaleTimeString(),
        comments: Math.floor(Math.random() * 20),
        timestamp: new Date().toISOString(),
      };

      setFeed(prev => [newPost, ...prev]);
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="max-w-2xl mx-auto mt-6">
      <h2 className="text-2xl font-bold mb-4 text-center">📢 Live Feed</h2>
      {feed.map(post => {
        const user = users.find(u => u.id === post.userId);

        if (!user) return null;

        return (
          <div key={post.id} className="mb-4 p-4 border border-gray-300 rounded-lg shadow-sm bg-white">
            <p className="text-lg"><strong>{user.name}</strong>: {post.content}</p>
            <p className="text-sm text-gray-500 mt-1">{new Date(post.timestamp).toLocaleString()}</p>
          </div>
        );
      })}
    </div>
  );
};

export default Feed;
