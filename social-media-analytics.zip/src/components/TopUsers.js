import React from 'react';
import { users } from '../mockData';
import './TopUsers.css';
const TopUsers = () => {
  const topUsers = users.slice(0, 5);
  return (
    <div className="top-users-container">
      <h2>Top Users</h2>
      <ul>
        {topUsers.map(user => (
          <li key={user.id} className="user-item">
            {user.name}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TopUsers;
