import React from 'react';
import { posts } from '../mockData';
import './TrendingPosts.css';

const TrendingPosts = () => {
  const maxComments = Math.max(...posts.map(p => p.comments));
  const trending = posts.filter(p => p.comments === maxComments);

  return (
    <div className="trending-container">
      <h2 className="title">🔥 Trending Posts</h2>
      {trending.map(post => (
        <div key={post.id} className="trending-post">
          <p><strong>{post.user}</strong>: {post.content}</p>
          <p className="comment-count">💬 {post.comments} comments</p>
        </div>
      ))}
    </div>
  );
};

export default TrendingPosts;
