export const users = [
  { id: 1, name: "John Doe" },
  { id: 2, name: "Jane Doe" },
  { id: 3, name: "Alice Smith" },
  { id: 4, name: "Bob Johnson" },
  { id: 5, name: "Charlie Brown" },
  { id: 6, name: "Diana White" },
  { id: 7, name: "Edward Davis" },
  { id: 8, name: "Fiona Miller" },
  { id: 9, name: "George Wilson" },
  { id: 10, name: "Helen Moore" },
  { id: 11, name: "Ivy Taylor" },
  { id: 12, name: "Jack Anderson" },
  { id: 13, name: "Kathy Thomas" },
  { id: 14, name: "Liam Jackson" },
  { id: 15, name: "Mona Harris" },
  { id: 16, name: "Nathan Clark" },
  { id: 17, name: "Olivia Lewis" },
  { id: 18, name: "Paul Walker" },
  { id: 19, name: "Quinn Scott" },
  { id: 20, name: "Rachel Young" }
];

  
  export const posts = [
    {
      id: 101,
      user: "Alice",
      content: "Loving this new feature!",
      comments: 12,
      timestamp: new Date().toISOString(),
    },
    {
      id: 102,
      user: "Bob",
      content: "React is powerful!",
      comments: 15,
      timestamp: new Date().toISOString(),
    },
    {
      id: 103,
      user: "Charlie",
      content: "Check out this post",
      comments: 8,
      timestamp: new Date().toISOString(),
    },
  ];
  